# Word Ladder

A mobile word-puzzle game. Change ONE letter at a time to turn the start word into the target word.

- Any letter position, any number of times, no row limit
- Wrong words cost a step; beat par for a perfect run
- 274 hand-filtered 3/4/5-letter puzzles, dictionary-validated
- Single self-contained `index.html` — no build step, no dependencies

**Play:** enable GitHub Pages (Settings → Pages → main / root) and open `https://<username>.github.io/word-ladder/`.

On iPhone: open in Safari → Share → *Add to Home Screen* for a full-screen app.
